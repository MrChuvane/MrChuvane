# 📊 Dashboards em Power BI

Dois dashboards desenvolvidos em Power BI, cobrindo gestão de dados de projecto e análise de dados de comunicação comunitária.

## 1. `FWW_2026.pbix`
Dashboard de monitoria de dados do projecto (Fundação Wiwanana, 2026), com acompanhamento de indicadores, actividades e beneficiários.

## 2. `WhatsApp_Group_Dashboard.pbix`
Dashboard de análise de dados de um grupo de WhatsApp — mensagens, participação e padrões de actividade ao longo do tempo.

## Como abrir

Estes ficheiros requerem o **Microsoft Power BI Desktop** (gratuito, Windows) para abrir e editar:
👉 https://powerbi.microsoft.com/desktop/

## Tecnologias

- Power BI (modelação de dados, DAX, visualizações interactivas)
