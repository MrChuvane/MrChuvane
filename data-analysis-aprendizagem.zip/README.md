# 🚦 Análise de Acidentes de Trânsito — Notebook de Aprendizagem

Notebook Jupyter de prática em análise de dados com Python: limpeza de dados, geolocalização e visualização.

## O que o notebook cobre

- Leitura e limpeza de um dataset de acidentes de trânsito (`pandas`), removendo registos sem coordenadas
- Mapas de calor (heatmap) de ocorrências com **Folium**
- Agrupamento de ocorrências no mapa com `MarkerCluster`
- Conversão e tratamento de datas (`pd.to_datetime`)
- Distribuição de acidentes por ano, visualizada com **Matplotlib**

## Tecnologias

- Python
- `pandas` — limpeza e manipulação de dados
- `folium` — mapas interactivos e geolocalização
- `matplotlib` — visualização de dados

## Como executar

```bash
pip install pandas folium matplotlib jupyter
jupyter notebook acidentes_transito_analise.ipynb
```

> Nota: o notebook foi feito como exercício de aprendizagem — o dataset de origem (`cat_acidentes.csv`) não está incluído neste repositório.
